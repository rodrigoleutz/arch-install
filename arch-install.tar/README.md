# arch-install
Arch install script
